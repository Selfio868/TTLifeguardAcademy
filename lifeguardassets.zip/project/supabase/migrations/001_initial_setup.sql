-- Create extensions
create extension if not exists "uuid-ossp";

-- Create assets table
create table if not exists public.assets (
    id uuid default uuid_generate_v4() primary key,
    created_at timestamp with time zone default timezone('utc'::text, now()) not null,
    created_by uuid references auth.users(id),  -- Reference to auth.users table
    name text not null,
    description text,
    category text,
    thumbnail_url text,
    model_url text,
    formats text[] default array[]::text[],
    file_size jsonb default '{}'::jsonb
);

-- Create storage buckets if they don't exist
insert into storage.buckets (id, name, public)
values ('models', 'models', true)
on conflict (id) do nothing;

insert into storage.buckets (id, name, public)
values ('thumbnails', 'thumbnails', true)
on conflict (id) do nothing;

-- Enable RLS
alter table public.assets enable row level security;

-- Create RLS policies
create policy "Public read access"
on public.assets for select
to anon
using (true);

create policy "Authenticated users can insert"
on public.assets for insert
to authenticated
with check (auth.uid() = created_by);

create policy "Authenticated users can update their own assets"
on public.assets for update
to authenticated
using (auth.uid() = created_by);

create policy "Authenticated users can delete their own assets"
on public.assets for delete
to authenticated
using (auth.uid() = created_by);

-- Storage policies
create policy "Public read access"
on storage.objects for select
to public
using (bucket_id in ('models', 'thumbnails'));

create policy "Authenticated users can upload"
on storage.objects for insert
to authenticated
with check (bucket_id in ('models', 'thumbnails'));

create policy "Authenticated users can update their own files"
on storage.objects for update
to authenticated
using (auth.uid() = owner);

create policy "Authenticated users can delete their own files"
on storage.objects for delete
to authenticated
using (auth.uid() = owner);