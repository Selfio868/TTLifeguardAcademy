-- Create admin role
create role admin;

-- Grant admin role to specific users
create or replace function public.is_admin(user_id uuid)
returns boolean as $$
begin
  return exists (
    select 1
    from auth.users
    where id = user_id
    and raw_user_meta_data->>'is_admin' = 'true'
  );
end;
$$ language plpgsql security definer;

-- Update RLS policies to allow admin access
create policy "Admin full access"
on public.assets
for all
to authenticated
using (is_admin(auth.uid()))
with check (is_admin(auth.uid()));

-- Admin storage access
create policy "Admin storage access"
on storage.objects
for all
to authenticated
using (is_admin(auth.uid()))
with check (is_admin(auth.uid()));